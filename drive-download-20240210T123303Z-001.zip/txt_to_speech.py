from googletrans import Translator
from gtts import gTTS
from io import BytesIO
from pydub import AudioSegment
from pydub.playback import play


def translate_text(text, dest_language):
    translator = Translator()
    translation = translator.translate(text, dest=dest_language)
    return translation.text


def text_to_speech(text, lang='en'):
    tts = gTTS(text=text, lang=lang, slow=False)
    mp3_fp = BytesIO()
    tts.write_to_fp(mp3_fp)
    mp3_fp.seek(0)
    audio = AudioSegment.from_file(mp3_fp, format="mp3")
    play(audio)


# Example usage
if __name__ == "__main__":
    text = input("Enter the text in English: ")
    language_code = input("Enter the target language code (hi for Hindi, mr for Marathi): ")

    # Translate text
    translated_text = translate_text(text, dest_language=language_code)
    print(f"Translated text: {translated_text}")

    # Convert translated text to speech
    text_to_speech(translated_text, lang=language_code)
