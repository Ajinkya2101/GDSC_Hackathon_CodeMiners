import speech_recognition as sr
from translate import Translator


def transcribe_and_translate_audio(language_code):
    # Initialize recognizer
    r = sr.Recognizer()

    # Check if the language code is supported
    if language_code not in ['hi', 'mr']:
        return "Unsupported language code. Please use 'hi' for Hindi or 'mr' for Marathi."

    # Initialize microphone
    with sr.Microphone() as source:
        print("Speak something:")
        r.adjust_for_ambient_noise(source, duration=0.5)
        audio = r.listen(source)

    try:
        # Transcribe audio using the specified language
        text = r.recognize_google(audio, language=language_code)
        print(f"Detected text: {text}")

        # Translate to English if the language is Hindi or Marathi
        translator = Translator(from_lang=language_code, to_lang="en")
        translation = translator.translate(text)
        return translation
    except sr.UnknownValueError:
        print("Could not understand audio")
        return "Error: Speech was unintelligible"
    except sr.RequestError as e:
        print(f"Could not request results; {e}")
        return f"Error: API request failed {e}"


# Ask the user for the language code
language_code = input("Enter the ISO 639-1 code of the language you will speak (hi for Hindi, mr for Marathi): ")

# Perform live transcription and translation based on the user's language choice
transcribed_and_translated_text = transcribe_and_translate_audio(language_code)
if transcribed_and_translated_text:
    print(f"Final output: {transcribed_and_translated_text}")
else:
    print("No text transcribed.")
