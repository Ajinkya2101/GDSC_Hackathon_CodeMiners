from googletrans import Translator


def translate_text(text, src_language, dest_language):
    translator = Translator()
    translation = translator.translate(text, src=src_language, dest=dest_language)
    return translation.text


# Ask the user for the text and the source and target languages
text_to_translate = input("Enter the text to translate: ")
source_language = input("Enter the ISO 639-1 code of the source language: ").lower()
destination_language = input("Enter the ISO 639-1 code of the destination language: ").lower()

# Perform the translation
translated_text = translate_text(text_to_translate, source_language, destination_language)

print(f"Original text: {text_to_translate}")
print(f"Translated text: {translated_text}")
